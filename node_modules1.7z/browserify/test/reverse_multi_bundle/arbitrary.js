var i = 0;
module.exports = function() {
    return ++i;
};

// 175e62
