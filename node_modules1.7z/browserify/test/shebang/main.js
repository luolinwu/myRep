#!/usr/bin/env node

var foo = require('./foo');
t.equal(foo, 1234);
