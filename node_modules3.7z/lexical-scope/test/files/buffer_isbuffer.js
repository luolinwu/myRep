console.log(Buffer.isBuffer('whatever'))
