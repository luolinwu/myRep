var x = 5;
var y = 3, z = 2;

w.foo();
w = 2;

RAWR=444;
RAWR.foo();

BLARG=3;

foo(function () {
    var BAR = 3;
    process.nextTick(function (ZZZZZZZZZZZZ) {
        console.log('beep boop');
        var xyz = 4;
        x += 10;
        x.zzzzzz;
        ZZZ=6;
    });
    function doom () {
        if (AAA.aaa) {}
        BBB.bbb = 3;
        var z = 2 + CCC.x * 5;
    }
    ZZZ.foo();

});

function beep () {}

console.log(xyz);
