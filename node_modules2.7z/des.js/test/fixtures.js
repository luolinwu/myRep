'use strict';

exports.bin = function bin(str) {
  return parseInt(str.replace(/[^01]/g, ''), 2);
}
