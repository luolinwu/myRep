<template>
  <text class="message">Now, let's use Vue.js to build your Weex app.</text>
</template>
